package oops_casting_conversion_primitive_type;

public class Implicite_casting {
      
	public static void main(String[] args) {
		
		int a=100;
		double b=a;
		
		System.out.println(b);
		

	}

}
