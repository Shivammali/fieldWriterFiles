package oops_casting_conversion_primitive_type;

public class explicite_casting {

	public static void main(String[] args) {
		
		
		double a=10.0;
		int b=(int)a;
		System.out.println(b);

	}

}
