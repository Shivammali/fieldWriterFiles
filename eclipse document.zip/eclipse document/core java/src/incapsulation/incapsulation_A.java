package incapsulation;

public class incapsulation_A {
	
	private int ID;
	private String name;
	
	public void setdata(int ID) {
	
		this.ID=ID;
		//System.out.println(101);
	}
	public int getdata() {
		
		return(ID);
	}
	public void setdata(String name) {
		
		this.name=name;
	 // System.out.println("siddhesh");
	}
	public String Getdata() {
		
		return(name);
	}
	
}
