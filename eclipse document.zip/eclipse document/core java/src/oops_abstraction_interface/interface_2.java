package oops_abstraction_interface;

interface interface_2 {
	
	public void test6(); 
		//incomplete method
	
		default void test5() {
		System.out.println("from interface 2");		
	}	

}
