package oops_casting_conversion_nonprimitive;

public class BBB {
	public void test() {
		
		System.out.println(2000);
	}

}
