package oops_single_level_inheritence;

public class Super {

	public static void StudInfo() {
		int StudId=101;
		String StudName="vikas";
		
		System.out.println(StudId+" "+StudName);	
	}
	public void StudInfo4() {
		int StudId=104;
		String StudName="samir";
		
		System.out.println(StudId+" "+StudName);	
	}
	}

