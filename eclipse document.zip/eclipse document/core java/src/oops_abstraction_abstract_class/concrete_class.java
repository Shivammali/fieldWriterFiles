package oops_abstraction_abstract_class;

public class concrete_class extends Abstract_class {
	
	public void test() {
		
		System.out.println(9000);
	}
	
	public static void main(String[] args) {
		
		test1();
		
		concrete_class ab=new concrete_class();
		 
		ab.test();
		
	
		
		
	
	}

}
