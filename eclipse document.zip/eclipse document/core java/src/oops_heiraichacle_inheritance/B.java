package oops_heiraichacle_inheritance;

public class B extends C {

	public static void main(String[] args) {
		
         B.StudInfo1();
		B bc=new B();
		bc.StudInfo2();
	}

}
