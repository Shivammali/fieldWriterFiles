package oops_heiraichacle_inheritance;

public class C {
	
	public static void StudInfo1() {
		int StudId=101;
		String StudName="siddhesh";
		
		System.out.println(StudId+" "+StudName);	
	}
	public void StudInfo2() {
		int StudId=102;
		String StudName="archit";
		
		System.out.println(StudId+" "+StudName);	
	}
	

	public static void main(String[] args) {
		
		
		

	}

}
