package oops_heiraichacle_inheritance;

public class A extends C{

	public static void main(String[] args) {
		
		A.StudInfo1();
		A ac=new A();
		ac.StudInfo2();
		

	}

}
