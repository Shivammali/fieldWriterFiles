
public class HellowFriends {

	public static void main(String[] args) {
		String username ="siddhesh";
		String pwd ="siddhesh@23";
		
		if( username=="siddhesh") {
		if( pwd=="siddhesh@123"){
			
			System.out.println("login successfully:");
		}else {
			System.out.println("please enter correct password:");		
			
		}
		
		}else {
			System.out.println("please enter correct username:");		
			
		}
		
		}
	}



		
		
