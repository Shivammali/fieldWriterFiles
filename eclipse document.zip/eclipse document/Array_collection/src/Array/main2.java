package Array;

import java.util.Arrays;

public class main2 {

	public static void main(String[] args) {//with object
		
        int a[]=new int[5];
        
        a[0]=50;
        a[1]=10;
        a[2]=20;
        a[3]=40;
        a[4]=30;
        
        System.out.println("length of index");
        
        int len=a.length;
        System.out.println(len);
        
        System.out.println("given index");
        
        for(int i=0;i<len;i++) {
        System.out.println(a[i]);	
        }	
        System.out.println("sorted index");	
        Arrays.sort(a);
        for(int i=0;i<len;i++) {
    	System.out.println(a[i]);   
    	   
        }
        System.out.println("decending order");	
        for(int i=len-1;i>=0;i--) {
        System.out.println(a[i]);	
        	
        }
        
        }
	}

	

