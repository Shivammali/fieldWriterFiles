package Array;
import java.util.Arrays;
public class main {

	public static void main(String[] args) {//without object
	
		int a[]= {50,20,10,40,30};
		
			 System.out.println(a[4]);//to print perticuler vallue from index
			 
		int len=a.length;
		System.out.println(len);//length of index
		
		
		for(int i=0;i<len;i++) {
			
			System.out.println(a[i]);
		}	 
		Arrays.sort(a);
		for(int i=0;i<len;i++) {
		System.out.println(a[i]);
		}
	}
}
