package methodcalling;

public class A {
	public static void aOne() {
	int EmpId=101;
	String EmpName="siddhesh";
	
	System.out.println(EmpId);
	System.out.println(EmpName);	
	
	
	}

}
