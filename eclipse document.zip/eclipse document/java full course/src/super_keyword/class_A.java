package super_keyword;

public class class_A {
	
	
	int a=25;
	
	
	public void test() {
		
		System.out.println("parent class method running");
	}
	
	class_A(){
	
		System.out.println("parent class constructor running");	
	}
	
	public static void main(String[]args) {
		
		
		
		
	}

}
