package loops_in_java;

public class While_loop {

	public static void main(String[] args) {
		
		int i=0; // initialization
		
		while(i<=20) { //condition
			
			
			System.out.print(" "+i);
		i++; // increment
		
	
	}
	}
}
