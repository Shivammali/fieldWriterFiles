package loops_in_java;

public class Do_While_loop {

	public static void main(String[] args) {
		
		int i=10;
		
		do{
			System.out.print(" "+i);
			i++;
		}
		while(i<=20);
			
		}	
}
	
	