package loops_in_java;

public class For_loop {

	public static void main(String[] args) {
		
		//initialization,condition,increment/decrement
		
		for(int i=0;i<=10;i++){
		
			System.out.print(" "+i);
			
			
		}
	}

}
