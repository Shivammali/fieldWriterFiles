package Spacial_Logic_Programme;

public class prime_numbers {
	
	public static void main(String[]args) {
		
	int a=23;
	int b=0;
	for(int i=2;i<=a-1;i++) {
		
		if(a%i==0) {
			b++;
			break;
		}
	}
		if(b==0) {
			
			System.out.println("prime number");
		}
		else {
			
			System.out.println(" not a prime number");
		 }
		}		
	  }
	
	
