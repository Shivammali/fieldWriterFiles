package Spacial_Logic_Programme;

public class Even_Odd_numbers {

	public static void main(String[] args) {

         int i=9;
         
		if(i%2==0) 
		{
		System.out.print("even number:");
		
		}
		else {
			System.out.println(" odd number:");	
		}	
		}	
		
}
	
	
