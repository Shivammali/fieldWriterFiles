package controlstatement;

public class if_statement {

	public static void main(String[] args) {
		
	int f=15;
	if(f<15){
		
	System.out.println("vallue is not greater than 15");
	}
	
	System.out.println("vallue is greater than 15");
	
	}	

}