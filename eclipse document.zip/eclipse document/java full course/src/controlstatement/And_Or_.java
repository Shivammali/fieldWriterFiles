package controlstatement;

public class And_Or_ {

	public static void main(String[] args) {
		int marks=75;
		
	if(marks>=60 || marks>=80) {/* false for AND true for OR
		  
		                &     ||        
		TRUE TRUE     TRUE   TRUE
		TRUE FALSE    FALSE  TRUE
		FALSE TRUE    FALSE  TRUE
		FALSE FALSE   FALSE  FALSE    */
		
		
		System.out.println("distinguation");
	}

	}

}
