package sampleprogramm;

public class Variable_Declaration {
	
	public void test(){
		String name="Ajay";
		int a=21;
		System.out.println(name);
	}

	public static void main(String[] args)
	{
	 
		Variable_Declaration ab=new Variable_Declaration();
		
		ab.test();
	}
	

}
