package Operators_in_java;

public class ternary_operator {

	public static void main(String[] args) {
		
		int n1=5 ,n2=10,max; //variable declairation
		
		System.out.println("first number:"+n1);
		System.out.println("second number:"+n2);
		
		max=(n1>n2)?n1:n2;
		System.out.println("maximum number:"+max);
		
		
		
		
	}

}
