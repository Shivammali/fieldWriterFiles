package Operators_in_java;

public class shift_operator {
	
	public static void main(String[] args) {
		
		int a=8;
		int b=5;
		
       System.out.println(a<<3);//8*2*2*2=64
       System.out.println(b<<3);//5*2*2*2=40
        
	}

}