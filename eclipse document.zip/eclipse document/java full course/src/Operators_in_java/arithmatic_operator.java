package Operators_in_java;

public class arithmatic_operator {

	public static void main(String[] args) {
		int a=48;
		int b=5;
		
		System.out.println("addition of      :"+(a+b));
		System.out.println("substrsction of  :"+(a-b));
		System.out.println("multiplication of:"+(a*b));
		System.out.println("division of      :"+(a/b));
		System.out.println("remender of      :"+(a%b));
		
		
	}

}