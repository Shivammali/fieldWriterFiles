package Operators_in_java;

public class Unary_Operator {

	public static void main(String[] args) {
		
     int a=9;
     System.out.println(a++);//a+1 9
     System.out.println(++a);//1+a 11
     System.out.println(a--);//a-1 11
     System.out.println(--a);//a-1 9
     
     
     
     
	}

}
                             